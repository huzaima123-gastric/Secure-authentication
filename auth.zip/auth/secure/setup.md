
# Project Setup Instructions

## Quick Start (After Download)

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Create Environment File**
   ```bash
   cp .env.example .env
   ```

3. **Edit `.env` file with your values:**
   ```
   JWT_SECRET=your-super-secret-jwt-key-here-make-it-long-and-random
   SESSION_SECRET=another-super-secret-session-key-here
   ENCRYPTION_KEY=your-aes-256-encryption-key-32-chars
   GOOGLE_CLIENT_ID=your-google-oauth-client-id
   GOOGLE_CLIENT_SECRET=your-google-oauth-client-secret
   PORT=5000
   ```

4. **Run the Application**
   ```bash
   node server.js
   ```

5. **Access the App**
   - Open your browser to `http://localhost:5000`
   - The authentication system will be ready to use!

## Features Available
✅ User Registration & Login  
✅ JWT Authentication  
✅ Two-Factor Authentication (2FA)  
✅ Google OAuth Integration  
✅ AES-256 Data Encryption  
✅ Rate Limiting & Security Headers  
✅ Responsive UI  

## For Google OAuth Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add your domain to authorized origins
6. Copy Client ID and Secret to `.env`

Your secure authentication system is now ready to use! 🔐
