
class AuthSystem {
    constructor() {
        this.token = localStorage.getItem('authToken');
        this.currentUser = null;
        this.mockUsersData = null;
        this.currentPage = 1;
        this.totalPages = 1;
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuthStatus();
        this.handleOAuthCallback();
        this.initPasswordStrengthMeter();
    }

    bindEvents() {
        // Toggle between login and register
        document.getElementById('loginBtn').addEventListener('click', () => this.showLogin());
        document.getElementById('registerBtn').addEventListener('click', () => this.showRegister());

        // Form submissions
        document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('registerForm').addEventListener('submit', (e) => this.handleRegister(e));

        // Dashboard actions
        document.getElementById('logoutBtn').addEventListener('click', () => this.logout());
        document.getElementById('setup2FABtn').addEventListener('click', () => this.setup2FA());
        document.getElementById('verify2FABtn').addEventListener('click', () => this.verify2FA());

        // Modal controls
        document.getElementById('closeModal').addEventListener('click', () => this.closeModal());
        document.querySelector('.modal').addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal();
            }
        });

        // Mock users data
        document.getElementById('loadMockUsers').addEventListener('click', () => this.loadMockUsers());
        document.getElementById('prevPage').addEventListener('click', () => this.previousPage());
        document.getElementById('nextPage').addEventListener('click', () => this.nextPage());

        // Password strength validation
        document.getElementById('registerPassword').addEventListener('input', (e) => this.updatePasswordStrength(e.target.value));
        
        // Real-time email check for 2FA requirement
        document.getElementById('loginEmail').addEventListener('blur', () => this.checkTwoFactorRequired());

        // Auto-format 2FA codes
        document.getElementById('twoFactorCode').addEventListener('input', (e) => this.formatTwoFactorCode(e));
        document.getElementById('verifyCode').addEventListener('input', (e) => this.formatTwoFactorCode(e));
    }

    showLogin() {
        document.getElementById('loginBtn').classList.add('active');
        document.getElementById('registerBtn').classList.remove('active');
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('registerForm').style.display = 'none';
    }

    showRegister() {
        document.getElementById('registerBtn').classList.add('active');
        document.getElementById('loginBtn').classList.remove('active');
        document.getElementById('registerForm').style.display = 'block';
        document.getElementById('loginForm').style.display = 'none';
    }

    async checkAuthStatus() {
        if (this.token) {
            try {
                await this.loadProfile();
                this.showDashboard();
            } catch (error) {
                this.logout();
            }
        }
    }

    handleOAuthCallback() {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('token');
        const userStr = urlParams.get('user');
        const error = urlParams.get('error');

        if (error) {
            this.showNotification('OAuth authentication failed', 'error');
            window.history.replaceState({}, document.title, window.location.pathname);
            return;
        }

        if (token && userStr) {
            try {
                this.token = token;
                this.currentUser = JSON.parse(decodeURIComponent(userStr));
                localStorage.setItem('authToken', token);
                this.showDashboard();
                this.loadProfile();
                this.showNotification('Successfully logged in with Google!', 'success');
                window.history.replaceState({}, document.title, window.location.pathname);
            } catch (error) {
                console.error('OAuth callback error:', error);
                this.showNotification('Failed to process OAuth login', 'error');
            }
        }
    }

    initPasswordStrengthMeter() {
        const passwordInput = document.getElementById('registerPassword');
        if (passwordInput) {
            passwordInput.addEventListener('input', (e) => {
                this.updatePasswordStrength(e.target.value);
                this.validatePasswordRequirements(e.target.value);
            });
        }
    }

    updatePasswordStrength(password) {
        const strengthBar = document.getElementById('strengthBar');
        const strengthText = document.getElementById('strengthText');
        
        if (!strengthBar || !strengthText) return;

        const strength = this.calculatePasswordStrength(password);
        
        strengthBar.style.width = `${strength.percentage}%`;
        strengthBar.style.background = strength.color;
        strengthText.textContent = strength.text;
        strengthText.style.color = strength.color;
    }

    calculatePasswordStrength(password) {
        let score = 0;
        let feedback = 'Very Weak';
        let color = '#ff3366';

        if (password.length >= 8) score += 20;
        if (password.length >= 12) score += 10;
        if (/[a-z]/.test(password)) score += 20;
        if (/[A-Z]/.test(password)) score += 20;
        if (/[0-9]/.test(password)) score += 15;
        if (/[^A-Za-z0-9]/.test(password)) score += 15;

        if (score >= 90) {
            feedback = 'Very Strong';
            color = '#00ff88';
        } else if (score >= 70) {
            feedback = 'Strong';
            color = '#00ffff';
        } else if (score >= 50) {
            feedback = 'Moderate';
            color = '#ffaa00';
        } else if (score >= 30) {
            feedback = 'Weak';
            color = '#ff6b00';
        }

        return {
            percentage: Math.min(score, 100),
            text: feedback,
            color: color
        };
    }

    validatePasswordRequirements(password) {
        const requirements = {
            lengthReq: password.length >= 8,
            uppercaseReq: /[A-Z]/.test(password),
            lowercaseReq: /[a-z]/.test(password),
            numberReq: /[0-9]/.test(password),
            specialReq: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        Object.keys(requirements).forEach(reqId => {
            const element = document.getElementById(reqId);
            if (element) {
                const icon = element.querySelector('.requirement-icon');
                if (requirements[reqId]) {
                    element.classList.add('valid');
                    icon.textContent = '✅';
                } else {
                    element.classList.remove('valid');
                    icon.textContent = '❌';
                }
            }
        });
    }

    formatTwoFactorCode(event) {
        let value = event.target.value.replace(/\D/g, '');
        if (value.length > 6) {
            value = value.substring(0, 6);
        }
        event.target.value = value;
    }

    async checkTwoFactorRequired() {
        // This is a placeholder - in a real app, you might check if the email requires 2FA
        // For demo purposes, we'll show the 2FA field if the email contains "2fa"
        const email = document.getElementById('loginEmail').value;
        const twoFactorGroup = document.getElementById('twoFactorGroup');
        
        if (email.toLowerCase().includes('2fa')) {
            twoFactorGroup.style.display = 'block';
        } else {
            twoFactorGroup.style.display = 'none';
        }
    }

    async handleLogin(event) {
        event.preventDefault();
        
        const submitBtn = event.target.querySelector('.submit-btn');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        
        this.setButtonLoading(submitBtn, btnText, btnLoading, true);

        const formData = {
            email: document.getElementById('loginEmail').value,
            password: document.getElementById('loginPassword').value,
            twoFactorCode: document.getElementById('twoFactorCode').value
        };

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.token;
                this.currentUser = data.user;
                localStorage.setItem('authToken', this.token);
                this.showDashboard();
                this.loadProfile();
                this.showNotification('Login successful!', 'success');
            } else {
                if (data.requires2FA) {
                    document.getElementById('twoFactorGroup').style.display = 'block';
                    this.showNotification('Please enter your 2FA code', 'warning');
                } else {
                    this.showNotification(data.error || 'Login failed', 'error');
                }
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showNotification('Network error. Please try again.', 'error');
        } finally {
            this.setButtonLoading(submitBtn, btnText, btnLoading, false);
        }
    }

    async handleRegister(event) {
        event.preventDefault();
        
        const submitBtn = event.target.querySelector('.submit-btn');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        
        this.setButtonLoading(submitBtn, btnText, btnLoading, true);

        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            this.showNotification('Passwords do not match', 'error');
            this.setButtonLoading(submitBtn, btnText, btnLoading, false);
            return;
        }

        const formData = {
            name: document.getElementById('registerName').value,
            email: document.getElementById('registerEmail').value,
            password: password
        };

        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.token;
                this.currentUser = data.user;
                localStorage.setItem('authToken', this.token);
                this.showDashboard();
                this.loadProfile();
                this.showNotification('Account created successfully!', 'success');
            } else {
                this.showNotification(data.error || 'Registration failed', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            this.showNotification('Network error. Please try again.', 'error');
        } finally {
            this.setButtonLoading(submitBtn, btnText, btnLoading, false);
        }
    }

    setButtonLoading(button, textElement, loadingElement, isLoading) {
        if (isLoading) {
            button.classList.add('loading');
            textElement.style.display = 'none';
            loadingElement.style.display = 'inline';
            button.disabled = true;
        } else {
            button.classList.remove('loading');
            textElement.style.display = 'inline';
            loadingElement.style.display = 'none';
            button.disabled = false;
        }
    }

    showDashboard() {
        document.getElementById('authSection').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
        
        if (this.currentUser) {
            document.getElementById('userWelcome').textContent = `Welcome, ${this.currentUser.name}!`;
        }
    }

    showAuthSection() {
        document.getElementById('authSection').style.display = 'block';
        document.getElementById('dashboard').style.display = 'none';
    }

    async loadProfile() {
        try {
            const response = await fetch('/api/profile', {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                },
            });

            const data = await response.json();

            if (response.ok) {
                this.currentUser = data;
                this.displayProfile(data);
                this.updateSecurityStatus(data);
            } else {
                throw new Error(data.error || 'Failed to load profile');
            }
        } catch (error) {
            console.error('Profile load error:', error);
            this.showNotification('Failed to load profile', 'error');
        }
    }

    displayProfile(userData) {
        const profileInfo = document.getElementById('profileInfo');
        
        profileInfo.innerHTML = `
            <div class="profile-item">
                <strong>👤 Name:</strong> ${userData.name}
            </div>
            <div class="profile-item">
                <strong>📧 Email:</strong> ${userData.email}
            </div>
            <div class="profile-item">
                <strong>🔐 Provider:</strong> ${userData.provider || 'Local'}
            </div>
            <div class="profile-item">
                <strong>📅 Created:</strong> ${new Date(userData.createdAt).toLocaleDateString()}
            </div>
            ${userData.lastLogin ? `<div class="profile-item">
                <strong>🕒 Last Login:</strong> ${new Date(userData.lastLogin).toLocaleString()}
            </div>` : ''}
        `;

        // Display encrypted data
        if (userData.encryptedData) {
            const encryptedContent = document.getElementById('encryptedContent');
            encryptedContent.innerHTML = `
                <div class="encrypted-item">
                    <strong>Email:</strong> ${userData.encryptedData.email || 'N/A'}
                </div>
                <div class="encrypted-item">
                    <strong>Name:</strong> ${userData.encryptedData.name || 'N/A'}
                </div>
                <div class="encrypted-item">
                    <strong>Registration IP:</strong> ${userData.encryptedData.registrationIP || 'N/A'}
                </div>
                <div class="encrypted-item">
                    <strong>User Agent:</strong> ${userData.encryptedData.userAgent ? userData.encryptedData.userAgent.substring(0, 50) + '...' : 'N/A'}
                </div>
            `;
        }
    }

    updateSecurityStatus(userData) {
        const twoFactorEnabled = document.getElementById('twoFactorEnabled');
        const twoFactorStatus = document.getElementById('twoFactorStatus');
        const setup2FABtn = document.getElementById('setup2FABtn');

        if (userData.twoFactorEnabled) {
            twoFactorEnabled.textContent = 'Enabled';
            twoFactorEnabled.className = 'status-badge enabled';
            twoFactorStatus.textContent = 'Enabled';
            setup2FABtn.textContent = 'Disable 2FA';
        } else {
            twoFactorEnabled.textContent = 'Disabled';
            twoFactorEnabled.className = 'status-badge';
            twoFactorStatus.textContent = 'Disabled';
            setup2FABtn.textContent = 'Setup 2FA';
        }
    }

    async setup2FA() {
        if (this.currentUser && this.currentUser.twoFactorEnabled) {
            // Show disable 2FA confirmation
            if (confirm('Are you sure you want to disable two-factor authentication?')) {
                const password = prompt('Please enter your password to confirm:');
                if (password) {
                    await this.disable2FA(password);
                }
            }
            return;
        }

        try {
            const response = await fetch('/api/setup-2fa', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                },
            });

            const data = await response.json();

            if (response.ok) {
                document.getElementById('qrCode').innerHTML = `<img src="${data.qrCode}" alt="QR Code" style="max-width: 200px;">`;
                document.getElementById('secret').textContent = data.secret;
                document.getElementById('twoFactorModal').style.display = 'flex';
            } else {
                this.showNotification(data.error || '2FA setup failed', 'error');
            }
        } catch (error) {
            console.error('2FA setup error:', error);
            this.showNotification('Failed to setup 2FA', 'error');
        }
    }

    async verify2FA() {
        const code = document.getElementById('verifyCode').value;

        if (!code || code.length !== 6) {
            this.showNotification('Please enter a valid 6-digit code', 'error');
            return;
        }

        try {
            const response = await fetch('/api/verify-2fa', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`,
                },
                body: JSON.stringify({ token: code }),
            });

            const data = await response.json();

            if (response.ok) {
                this.closeModal();
                this.showNotification('2FA enabled successfully!', 'success');
                this.loadProfile(); // Refresh profile data
            } else {
                this.showNotification(data.error || 'Invalid 2FA code', 'error');
            }
        } catch (error) {
            console.error('2FA verification error:', error);
            this.showNotification('Failed to verify 2FA', 'error');
        }
    }

    async disable2FA(password) {
        try {
            const response = await fetch('/api/disable-2fa', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`,
                },
                body: JSON.stringify({ password }),
            });

            const data = await response.json();

            if (response.ok) {
                this.showNotification('2FA disabled successfully', 'success');
                this.loadProfile(); // Refresh profile data
            } else {
                this.showNotification(data.error || 'Failed to disable 2FA', 'error');
            }
        } catch (error) {
            console.error('2FA disable error:', error);
            this.showNotification('Failed to disable 2FA', 'error');
        }
    }

    closeModal() {
        document.getElementById('twoFactorModal').style.display = 'none';
        document.getElementById('verifyCode').value = '';
    }

    async loadMockUsers() {
        try {
            const response = await fetch(`/api/mock-users?page=${this.currentPage}&limit=10`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                },
            });

            const data = await response.json();

            if (response.ok) {
                this.mockUsersData = data;
                this.displayMockUsers(data.users);
                this.updatePagination(data.currentPage, data.totalPages, data.totalUsers);
                document.getElementById('mockUsersCount').textContent = data.totalUsers.toLocaleString();
            } else {
                this.showNotification(data.error || 'Failed to load mock users', 'error');
            }
        } catch (error) {
            console.error('Mock users load error:', error);
            this.showNotification('Failed to load mock users', 'error');
        }
    }

    displayMockUsers(users) {
        const container = document.getElementById('mockUsersTable');
        
        if (users.length === 0) {
            container.innerHTML = '<div class="loading">No users found</div>';
            return;
        }

        const table = document.createElement('table');
        table.className = 'users-table';
        
        table.innerHTML = `
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.firstName} ${user.lastName}</td>
                        <td>${user.email}</td>
                        <td>${user.gender}</td>
                        <td>${user.location}</td>
                    </tr>
                `).join('')}
            </tbody>
        `;
        
        container.innerHTML = '';
        container.appendChild(table);
    }

    updatePagination(currentPage, totalPages, totalUsers) {
        this.currentPage = currentPage;
        this.totalPages = totalPages;
        
        document.getElementById('pageInfo').textContent = `Page ${currentPage} of ${totalPages}`;
        document.getElementById('prevPage').disabled = currentPage <= 1;
        document.getElementById('nextPage').disabled = currentPage >= totalPages;
    }

    async previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            await this.loadMockUsers();
        }
    }

    async nextPage() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            await this.loadMockUsers();
        }
    }

    logout() {
        // Clear local storage
        localStorage.removeItem('authToken');
        this.token = null;
        this.currentUser = null;
        this.mockUsersData = null;
        
        // Reset forms
        document.getElementById('loginForm').reset();
        document.getElementById('registerForm').reset();
        document.getElementById('twoFactorGroup').style.display = 'none';
        
        // Show auth section
        this.showAuthSection();
        this.showLogin();
        
        // Show notification
        this.showNotification('Logged out successfully', 'success');
        
        // Optional: Call logout endpoint
        if (this.token) {
            fetch('/api/logout', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                },
            }).catch(error => console.error('Logout API error:', error));
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type}`;
        notification.classList.add('show');

        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
}

// Initialize the authentication system when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new AuthSystem();
});

// Add some global utilities
window.AuthUtils = {
    generateSecurePassword: () => {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < 16; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    },
    
    copyToClipboard: (text) => {
        navigator.clipboard.writeText(text).then(() => {
            // Could show a toast notification here
            console.log('Copied to clipboard');
        });
    }
};
