
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const CryptoJS = require('crypto-js');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"]
    }
  }
}));

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static('.'));

// Rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: { error: 'Too many authentication attempts, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { error: 'Too many requests, please try again later.' }
});

app.use('/api/register', authLimiter);
app.use('/api/login', authLimiter);
app.use(generalLimiter);

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key-here',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false, 
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    httpOnly: true
  }
}));

app.use(passport.initialize());
app.use(passport.session());

// In-memory database (replace with real database in production)
const users = new Map();
const sessions = new Map();
let mockUsers = [];

// Load mock data from CSV
function loadMockData() {
  const csvPath = path.join(__dirname, 'attached_assets', 'MOCK_DATA_1756233820666.csv');
  
  if (fs.existsSync(csvPath)) {
    fs.createReadStream(csvPath)
      .pipe(csv())
      .on('data', (row) => {
        // Convert CSV data to user format
        const mockUser = {
          id: row.id || `mock_${Date.now()}_${Math.random()}`,
          firstName: row.first_name,
          lastName: row.last_name,
          email: row.email,
          gender: row.gender,
          ipAddress: row.ip_address,
          location: row.id // Using the location info from first column
        };
        mockUsers.push(mockUser);
      })
      .on('end', () => {
        console.log(`Loaded ${mockUsers.length} mock users from CSV`);
      });
  } else {
    console.log('Mock data CSV not found, proceeding without it');
  }
}

// Load mock data on startup
loadMockData();

// Encryption functions using AES-256
const encryptData = (data) => {
  const key = process.env.ENCRYPTION_KEY || 'default-encryption-key-32-chars';
  return CryptoJS.AES.encrypt(JSON.stringify(data), key).toString();
};

const decryptData = (encryptedData) => {
  try {
    const key = process.env.ENCRYPTION_KEY || 'default-encryption-key-32-chars';
    const bytes = CryptoJS.AES.decrypt(encryptedData, key);
    return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  } catch (error) {
    console.error('Decryption error:', error);
    return null;
  }
};

// JWT middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'jwt-secret', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Google OAuth configuration
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID || 'your-google-client-id',
  clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'your-google-client-secret',
  callbackURL: "/auth/google/callback"
}, async (accessToken, refreshToken, profile, done) => {
  try {
    const userId = `google_${profile.id}`;
    const user = {
      id: userId,
      email: profile.emails[0].value,
      name: profile.displayName,
      firstName: profile.name.givenName,
      lastName: profile.name.familyName,
      provider: 'google',
      avatar: profile.photos[0]?.value,
      verified: true
    };

    // Encrypt user data
    const encryptedData = encryptData({
      profile: profile._json,
      accessToken: accessToken
    });

    users.set(userId, {
      ...user,
      encryptedData,
      twoFactorEnabled: false,
      twoFactorSecret: null,
      createdAt: new Date().toISOString()
    });

    return done(null, user);
  } catch (error) {
    return done(error, null);
  }
}));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  const user = users.get(id);
  done(null, user);
});

// Utility function to validate password strength
const validatePassword = (password) => {
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  return {
    isValid: password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
    errors: {
      length: password.length < minLength,
      uppercase: !hasUpperCase,
      lowercase: !hasLowerCase,
      number: !hasNumbers,
      special: !hasSpecialChar
    }
  };
};

// Routes

// Serve main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// User registration
app.post('/api/register', async (req, res) => {
  try {
    const { email, password, name, firstName, lastName } = req.body;

    // Validate input
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password, and name are required' });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return res.status(400).json({ 
        error: 'Password does not meet security requirements',
        requirements: passwordValidation.errors
      });
    }

    // Check if user already exists
    const existingUser = Array.from(users.values()).find(user => user.email === email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists with this email' });
    }

    // Hash password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    const userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

    // Create user object
    const user = {
      id: userId,
      email: email.toLowerCase(),
      name,
      firstName: firstName || name.split(' ')[0],
      lastName: lastName || name.split(' ').slice(1).join(' '),
      password: hashedPassword,
      twoFactorSecret: null,
      twoFactorEnabled: false,
      provider: 'local',
      verified: false,
      createdAt: new Date().toISOString(),
      lastLogin: null,
      loginAttempts: 0,
      lockUntil: null
    };

    // Encrypt sensitive data
    user.encryptedData = encryptData({
      email: user.email,
      name: user.name,
      registrationIP: req.ip,
      userAgent: req.get('User-Agent')
    });

    users.set(userId, user);

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId, 
        email: user.email,
        name: user.name
      }, 
      process.env.JWT_SECRET || 'jwt-secret',
      { expiresIn: '24h' }
    );

    // Log successful registration
    console.log(`New user registered: ${email} at ${new Date().toISOString()}`);

    res.status(201).json({ 
      message: 'User registered successfully',
      token,
      user: { 
        id: userId, 
        email: user.email, 
        name: user.name,
        twoFactorEnabled: user.twoFactorEnabled
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// User login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password, twoFactorCode } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user
    const user = Array.from(users.values()).find(u => u.email === email.toLowerCase());
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Check if account is locked
    if (user.lockUntil && new Date() < new Date(user.lockUntil)) {
      return res.status(423).json({ error: 'Account temporarily locked due to too many failed attempts' });
    }

    // Verify password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      // Increment login attempts
      user.loginAttempts = (user.loginAttempts || 0) + 1;
      if (user.loginAttempts >= 5) {
        user.lockUntil = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // Lock for 30 minutes
      }
      users.set(user.id, user);
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    // Check 2FA if enabled
    if (user.twoFactorEnabled) {
      if (!twoFactorCode) {
        return res.status(400).json({ 
          error: '2FA code required',
          requires2FA: true
        });
      }

      const verified = speakeasy.totp.verify({
        secret: user.twoFactorSecret,
        encoding: 'base32',
        token: twoFactorCode,
        window: 2
      });

      if (!verified) {
        return res.status(400).json({ error: 'Invalid 2FA code' });
      }
    }

    // Reset login attempts on successful login
    user.loginAttempts = 0;
    user.lockUntil = null;
    user.lastLogin = new Date().toISOString();
    users.set(user.id, user);

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: user.id, 
        email: user.email,
        name: user.name
      },
      process.env.JWT_SECRET || 'jwt-secret',
      { expiresIn: '24h' }
    );

    // Log successful login
    console.log(`User login: ${email} at ${new Date().toISOString()}`);

    res.json({
      message: 'Login successful',
      token,
      user: { 
        id: user.id, 
        email: user.email, 
        name: user.name,
        twoFactorEnabled: user.twoFactorEnabled,
        lastLogin: user.lastLogin
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Setup 2FA
app.post('/api/setup-2fa', authenticateToken, async (req, res) => {
  try {
    const user = users.get(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Generate secret for 2FA
    const secret = speakeasy.generateSecret({
      name: `SecureAuth (${user.email})`,
      issuer: 'SecureAuth System',
      length: 32
    });

    // Store the secret temporarily (not enabled yet)
    user.twoFactorSecret = secret.base32;
    users.set(user.id, user);

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);

    res.json({
      secret: secret.base32,
      qrCode: qrCodeUrl,
      manualEntryKey: secret.base32
    });
  } catch (error) {
    console.error('2FA setup error:', error);
    res.status(500).json({ error: '2FA setup failed' });
  }
});

// Verify and enable 2FA
app.post('/api/verify-2fa', authenticateToken, (req, res) => {
  try {
    const { token } = req.body;
    const user = users.get(req.user.userId);

    if (!user || !user.twoFactorSecret) {
      return res.status(400).json({ error: 'No 2FA secret found. Please setup 2FA first.' });
    }

    // Verify the token
    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token,
      window: 2
    });

    if (verified) {
      user.twoFactorEnabled = true;
      users.set(user.id, user);
      
      console.log(`2FA enabled for user: ${user.email}`);
      res.json({ message: '2FA enabled successfully' });
    } else {
      res.status(400).json({ error: 'Invalid 2FA code. Please try again.' });
    }
  } catch (error) {
    console.error('2FA verification error:', error);
    res.status(500).json({ error: '2FA verification failed' });
  }
});

// Disable 2FA
app.post('/api/disable-2fa', authenticateToken, (req, res) => {
  try {
    const { password } = req.body;
    const user = users.get(req.user.userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify password before disabling 2FA
    bcrypt.compare(password, user.password, (err, isValid) => {
      if (err || !isValid) {
        return res.status(400).json({ error: 'Invalid password' });
      }

      user.twoFactorEnabled = false;
      user.twoFactorSecret = null;
      users.set(user.id, user);

      console.log(`2FA disabled for user: ${user.email}`);
      res.json({ message: '2FA disabled successfully' });
    });
  } catch (error) {
    console.error('2FA disable error:', error);
    res.status(500).json({ error: 'Failed to disable 2FA' });
  }
});

// Google OAuth routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/?error=oauth_failed' }),
  (req, res) => {
    try {
      const token = jwt.sign(
        { 
          userId: req.user.id, 
          email: req.user.email,
          name: req.user.name
        },
        process.env.JWT_SECRET || 'jwt-secret',
        { expiresIn: '24h' }
      );

      console.log(`Google OAuth login: ${req.user.email} at ${new Date().toISOString()}`);
      res.redirect(`/?token=${token}&user=${encodeURIComponent(JSON.stringify(req.user))}`);
    } catch (error) {
      console.error('OAuth callback error:', error);
      res.redirect('/?error=oauth_error');
    }
  }
);

// Get user profile
app.get('/api/profile', authenticateToken, (req, res) => {
  try {
    const user = users.get(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Decrypt sensitive data
    const decryptedData = user.encryptedData ? decryptData(user.encryptedData) : {};

    res.json({
      id: user.id,
      email: user.email,
      name: user.name,
      firstName: user.firstName,
      lastName: user.lastName,
      provider: user.provider,
      twoFactorEnabled: user.twoFactorEnabled,
      verified: user.verified,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
      encryptedData: decryptedData
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Get mock users data (for demo purposes)
app.get('/api/mock-users', authenticateToken, (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;

    const paginatedUsers = mockUsers.slice(startIndex, endIndex);
    
    res.json({
      users: paginatedUsers,
      currentPage: page,
      totalPages: Math.ceil(mockUsers.length / limit),
      totalUsers: mockUsers.length
    });
  } catch (error) {
    console.error('Mock users fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch mock users' });
  }
});

// Logout
app.post('/api/logout', authenticateToken, (req, res) => {
  try {
    // In a real app, you'd blacklist the JWT token
    console.log(`User logout: ${req.user.email} at ${new Date().toISOString()}`);
    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Logout failed' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    activeUsers: users.size,
    mockUsers: mockUsers.length
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🔐 Secure Authentication Server running on port ${PORT}`);
  console.log(`🚀 Server started at ${new Date().toISOString()}`);
  console.log(`📊 Loaded ${mockUsers.length} mock users from CSV`);
  console.log(`🔒 Security features enabled: JWT, 2FA, OAuth, AES-256 encryption`);
});

module.exports = app;
